
package domain;

public class Administrator extends Actor {

}
