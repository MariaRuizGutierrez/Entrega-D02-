
package domain;

public class Sponsor extends Actor {

	// Attributes -------------------------------------------------------------

}
