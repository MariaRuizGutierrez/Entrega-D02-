
package domain;

public class Auditor extends Actor {

}
