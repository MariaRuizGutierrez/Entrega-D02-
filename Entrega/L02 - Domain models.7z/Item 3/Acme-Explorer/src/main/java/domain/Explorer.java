
package domain;

public class Explorer extends Actor {

	// Attributes -------------------------------------------------------------

}
